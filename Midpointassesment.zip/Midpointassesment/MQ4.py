def passwd_manager(Password):
    from string import ascii_letters as letters, digits, punctuation

    have_lettrs = have_digit = have_punctuation = False
    for character in Password:
        if character in letters:
            have_lettrs = True
        elif character in digits:
            have_digit = True
        elif character in punctuation:
            have_punctuation = True

    return have_lettrs and have_digit and have_punctuation

user_input = input("Enter a password: ")

print("Acceptable password" if passwd_manager(user_input) == True else "password not acceptable")