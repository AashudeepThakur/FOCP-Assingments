print("Greetings, What is the password : ") 
passwd = "I dont know"
while True:  
    user_passwd = str(input("Enter your password: "))
    if user_passwd == passwd:
        print("Correct you may enter")
        break
    else:
        print("Incorrect! Please enter the correct password")
        continue
    