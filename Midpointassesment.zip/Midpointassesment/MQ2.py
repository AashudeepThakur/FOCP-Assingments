while True:
    try:
        user_input = int(input("Enter the number of spam : "))
        if user_input > 0:
            break
        print("Please choose atleast one slice")
    except ValueError:
        print("Enter the number correctly!!")

if user_input == 1:
    print("Egg with spam coming up!")
else:
    spam = "spam, " * (user_input - 1)
    print(f"Egg with {spam} and spam coming up!")
